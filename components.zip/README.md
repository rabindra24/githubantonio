- Clerk Authentication
- PlanetScaler Database (My SQL)
- Shadcn-ui
- cloudinary
- next-cloudinary

* npx prisma init -y
* npx prisma generate
* npx prisma db push
* npx prisma migrate reset
* npx prisma db push --preview-feature

* stripe login

~ https://stackoverflow.com/questions/16073603/how-to-update-each-dependency-in-package-json-to-the-latest-version

~ https://www.google.com/search?q=update+latest+version+npm+package+in+react&rlz=1C1ONGR_enIN1051IN1051&ei=keGwZI-GL4az4-EPr9ud0Ao&ved=0ahUKEwjPkqrvv42AAxWG2TgGHa9tB6oQ4dUDCA8&uact=5&oq=update+latest+version+npm+package+in+react&gs_lp=Egxnd3Mtd2l6LXNlcnAiKnVwZGF0ZSBsYXRlc3QgdmVyc2lvbiBucG0gcGFja2FnZSBpbiByZWFjdDIFECEYoAEyBRAhGKABSK5bUABYlllwAngBkAEAmAGmAqABiSiqAQYzLjMxLjK4AQPIAQD4AQGoAgrCAgcQABiKBRhDwgIREC4YgAQYsQMYgwEYxwEY0QPCAhYQABgDGI8BGOoCGLQCGIwDGOUC2AEBwgIWEC4YAxiPARjqAhi0AhiMAxjlAtgBAcICGBAAGAMYjwEY6gIYtAIYChiMAxjlAtgBAcICCBAAGIoFGJECwgILEAAYgAQYsQMYgwHCAgsQABiKBRixAxiDAcICBRAAGIAEwgINEAAYigUYsQMYgwEYQ8ICCBAAGIAEGLEDwgIGEAAYFhgewgIIEAAYigUYhgPCAggQABgIGB4YDcICCBAhGBYYHhgdwgIHECEYoAEYCuIDBBgAIEGIBgG6BgQIARgK&sclient=gws-wiz-serp

`npm i -g npm-check-updates`
`ncu -u`
`npm i`
`npm i npm-check-updates -u`
